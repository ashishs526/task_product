@extends('welcome')
@section('title','index')
@section('content')
<div class="container">
  <div class="row">
    <div class="col-md-9">
      <div class="card">
        <div class="card-header bg-primery text-dark " style="background-color: aquamarine; text-align: center"><b>Add Product</b></div> 
        <div class="card-body" id="form-fillup">
          <form action="" enctype="multipart/form-data" id="addProductForm">
            @csrf
            <div class="form-group">
              <label for="">Product Name</label>
              <input type="text" name="productName" id="productName" class="form-control" placeholder="Enter product name..">
              <span class="text-danger error-text productNameError"></span>
            </div>
            <div class="form-group">
              <label for="">Product Price</label>
              <input type="number" name="price" id="price" class="form-control" placeholder="Enter product price">
              <span class="text-danger error-text priceError"></span>
            </div>
            <div class="form-group">
              <label for="">Product Discription</label>
              <input type="text" name="discription" id="discription" class="form-control" placeholder="Enter product discription">
              <span class="text-danger error-text discriptionError"></span>
            </div>
           
            <div class="form-group">
              <label for="">Product Image</label>
              <input type="file" name="productImage[]" id="productImage" class="form-control" accept="image/*" multiple>
              <span class="text-danger error-text productImageError"></span>
            </div>
          <input type="hidden" id="productid" name="productid" >
            
            <button type="submit" class="btn btn-primary add_product">submit</button>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>

<div class="container-fluid p-5" id="productTable">
  <table class="table">
    <thead class="thead-dark">
      <tr>
        <th scope="col">SN</th>
        <th scope="col">Name</th>
        <th scope="col">Price</th>
        <th scope="col">Discription</th>
        <th scope="col">Image</th>
        <th scope="col">Action</th>
      </tr>
     
    </thead>
    <tbody>
      @if(count($products) > 0)
        @foreach($products as $index => $product)
        <tr>
          <td scope="col">{{$index + 1}}</td>
          <td scope="col">{{$product->product_name}}</td>
          <td scope="col">{{$product->product_price}}</td>
          <td scope="col">{{$product->product_desccription}}</td>
        <td>
          @foreach($product->getImages as $productImage)
          <img src="uploads/products/{{$productImage->image}}" width="40" height="50"/>
          @endforeach
          </td>
          <td>
              <button type="button" class="btn btn-danger deleteBtn " id="{{$product->id}}">Delete</button>
              <button type="button" class="btn btn-warning editBtn" id="{{$product->id}}">Edit</button>
          </td>
        </tr>
        @endforeach
      @endif
    </tbody>
   
  </table>
</div>
@endsection