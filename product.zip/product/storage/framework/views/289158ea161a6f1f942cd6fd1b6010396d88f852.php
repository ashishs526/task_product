
<?php $__env->startSection('title','index'); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="row">
    <div class="col-md-9">
      <div class="card">
        <div class="card-header bg-primery text-dark " style="background-color: aquamarine; text-align: center"><b>Add Product</b></div> 
        <div class="card-body" id="form-fillup">
          <form action="" enctype="multipart/form-data" id="addProductForm">
            <?php echo csrf_field(); ?>
            <div class="form-group">
              <label for="">Product Name</label>
              <input type="text" name="productName" id="productName" class="form-control" placeholder="Enter product name..">
              <span class="text-danger error-text productNameError"></span>
            </div>
            <div class="form-group">
              <label for="">Product Price</label>
              <input type="number" name="price" id="price" class="form-control" placeholder="Enter product price">
              <span class="text-danger error-text priceError"></span>
            </div>
            <div class="form-group">
              <label for="">Product Discription</label>
              <input type="text" name="discription" id="discription" class="form-control" placeholder="Enter product discription">
              <span class="text-danger error-text discriptionError"></span>
            </div>
           
            <div class="form-group">
              <label for="">Product Image</label>
              <input type="file" name="productImage[]" id="productImage" class="form-control" accept="image/*" multiple>
              <span class="text-danger error-text productImageError"></span>
            </div>
          <input type="hidden" id="productid" name="productid" >
            
            <button type="submit" class="btn btn-primary add_product">submit</button>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>

<div class="container-fluid p-5" id="productTable">
  <table class="table">
    <thead class="thead-dark">
      <tr>
        <th scope="col">SN</th>
        <th scope="col">Name</th>
        <th scope="col">Price</th>
        <th scope="col">Discription</th>
        <th scope="col">Image</th>
        <th scope="col">Action</th>
      </tr>
     
    </thead>
    <tbody>
      <?php if(count($products) > 0): ?>
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td scope="col"><?php echo e($index + 1); ?></td>
          <td scope="col"><?php echo e($product->product_name); ?></td>
          <td scope="col"><?php echo e($product->product_price); ?></td>
          <td scope="col"><?php echo e($product->product_desccription); ?></td>
        <td>
          <?php $__currentLoopData = $product->getImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productImage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <img src="uploads/products/<?php echo e($productImage->image); ?>" width="40" height="50"/>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </td>
          <td>
              <button type="button" class="btn btn-danger deleteBtn " id="<?php echo e($product->id); ?>">Delete</button>
              <button type="button" class="btn btn-warning editBtn" id="<?php echo e($product->id); ?>">Edit</button>
          </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php endif; ?>
    </tbody>
   
  </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Xampp\htdocs\product\resources\views/index.blade.php ENDPATH**/ ?>