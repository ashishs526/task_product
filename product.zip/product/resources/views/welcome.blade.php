<!DOCTYPE html>
<html lang="en">
  <head>
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css" integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous">
    
  </head>
  <body class="goto-here">

        

        
        @section('content')
        @show
		
        <script src="{{ URL::asset('js/plugins/jquery.min.js') }}"></script>
        <script src="{{ URL::asset('js/plugins/bootstrap.min.js') }}"></script>
        
    <script src="{{ URL::asset('js/product.js') }}"></script>
  </body>
</html>