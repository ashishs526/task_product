<?php

namespace App\Http\Controllers;

use App\Models\Product;
use App\Models\ProductImage;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Response;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Support\Str;
use File;
use Image;

class ProductController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $products = Product::all();
        return view('index')->with(['products' => $products]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
        //
       
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request, Product $product)
    {
        if($request->productid != ''){

            $validator = Validator::make($request->all(),[
                'productName'=>'required',
                'price'=>'required',
                'discription'=>'required',
            ]);
            if($validator->fails())
            {
                return response()->json([
                    'status'=>400,
                    'errors'=>$validator->messages(),
                    ]);
                }else{
                    $product = Product::where("id", $request->productid)->update([
                        'product_name' => $request->productName,
                        'product_price' => $request->price,
                        'product_desccription' => $request->discription,
                    ]);
                    if($product){
                        if( $product> 0){
                            if($request->productImage > 0){
                                $product = ProductImage::where("product_id", $request->productid)->delete();
                                foreach($request->productImage as $index => $image){
                                    $fileName = time() . '_' . $image->getClientOriginalName();
                                    $location = "uploads/products/";
                                    $image->move($location, $fileName);
                                    $imagestore = ProductImage::create([
                                        'image' => $fileName,
                                        'product_id' => $request->productid,
                                    
                                    ]);
                                }

                            }                         
                             return response()->json([
                                'status'=>201,
                                'message'=>'product updated successfully',
                            ]);
                        }
                        
                    }else{
                        return response()->json([
                            'status'=>300,
                            'message'=>'here are some problem',
                        ]);
                    }
            }
            

        }else{
            $validator = Validator::make($request->all(),[
                'productName'=>'required',
                'price'=>'required',
                'discription'=>'required',
            ]);
            if($validator->fails())
            {
                return response()->json([
                    'status'=>400,
                    'errors'=>$validator->messages(),
                    ]);
                }else{
                    $product = Product::create([
                        'product_name' => $request->productName,
                        'product_price' => $request->price,
                        'product_desccription' => $request->discription,
                    ]);
                    if($product){
                        if(count($request->productImage) > 0){
                            foreach($request->productImage as $index => $image){
                                $fileName = time() . '_' . $image->getClientOriginalName();
                                $location = "uploads/products/";
                                $image->move($location, $fileName);
                                $imagestore = ProductImage::create([
                                    'image' => $fileName,
                                    'product_id' => $product->id,
                                
                                ]);
                                
                                
                            }
                            if($imagestore){
                                return response()->json([
                                    'status'=>200,
                                    'message'=>'product added successfully',
                                ]);
    
                            }
                        }
                        
                    }else{
                        return response()->json([
                            'status'=>300,
                            'message'=>'here are some problem',
                        ]);
                    }
            }
            
        }
        
       
        
      
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function show(Product $product)
    {
        $products = Product::all();
        return view('index', ['products' => $products]);

        // return response()->json([
        //     'products'=> $products,
        // ]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function edit(Product $product)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Product $product)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request, Product $product)
    {        
        if($product){
            $product->delete();
            return response()->json([
                'status'=>200,
                'message'=>'product deleted successfully',
            ]);
        }else{
            return response()->json([
                'status'=>200,
                'message'=>'Invalid prduct id',
            ]);
        }       

    }

     /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function fetchdata(Request $request, Product $product)
    {        
        
            
            return response()->json([
                'status'=>200,
                'product'=>$product,
            ]);    
    }
}
