$( document ).ready(function() {
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
    $(document).on('click','.add_product',function(e){
        e.preventDefault();
        var formData = new FormData($("#addProductForm")[0]);  
        $.ajax({
            type:"post",
            url: "/product",
            data: formData,           
            processData: false,
            contentType: false,
            success:function(response){
                if(response.status === 200){
                    alert(response.message);
                    $("#addProductForm")[0].reset();
                    location.reload();
                    getproductdata();
                }
                else if(response.status === 400){
                    $.each(response.errors, function(index, error){
                        $('.' + index + 'Error').text(error[0]);
                    })
                    //console.log(response.errors);
                }
                else if(response.status === 300){
                    alert(response.message);
                }
                else if(response.status === 201){
                    alert(response.message);
                    location.reload();
                    getproductdata();
                }
              
            },
           
        });

    });
    
   //getproductdata();
  

   $(document).on("click",".deleteBtn", function(e){
    e.preventDefault();            
        var product_id = $(this).attr('id');
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        $.ajax({
            type:"post",
            url: '/product_delete/'+ product_id,
            data:{},          
            success:function(response){
                alert(response.message);
                location.reload();
                getproductdata();
            }
        });

    });

    $(document).on("click",".editBtn", function(e){
        e.preventDefault();            
            var product_id = $(this).attr('id');
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({
                type:"get",
                url: '/product_detail/'+ product_id,
                data:{},          
                success:function(response){
                    $('#productName').val(response.product.product_name);
                    $('#price').val(response.product.product_price);
                    $('#discription').val(response.product.product_desccription);
                    $('#productid').val(response.product.id);
                }
            });
    
    });
    function getproductdata(){
        $.ajax({
            type:"get",
            url: "/product",         
            dataType:"json",
            success:function(data){
               
                $("#productTable").html(data); 
            },
           
        });
       }
});