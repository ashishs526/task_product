<!DOCTYPE html>
<html lang="en">
  <head>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css" integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous">
    
  </head>
  <body class="goto-here">

        

        
        <?php $__env->startSection('content'); ?>
        <?php echo $__env->yieldSection(); ?>
		
        <script src="<?php echo e(URL::asset('js/plugins/jquery.min.js')); ?>"></script>
        <script src="<?php echo e(URL::asset('js/plugins/bootstrap.min.js')); ?>"></script>
        
    <script src="<?php echo e(URL::asset('js/product.js')); ?>"></script>
  </body>
</html><?php /**PATH E:\Xampp\htdocs\product\resources\views/welcome.blade.php ENDPATH**/ ?>