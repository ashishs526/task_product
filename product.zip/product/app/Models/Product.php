<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\ProductImage;

class Product extends Model
{
    use HasFactory;
    protected $fillable=['product_name','product_price','product_desccription',];

    public function getImages(){
        return $this->hasMany(ProductImage::class, 'product_id', 'id');
    }
}
